package Main;

import Commands.BasicCommands;
import Commands.Clear;
import Commands.MemberJoin;
import net.dv8tion.jda.core.AccountType;
import net.dv8tion.jda.core.JDA;
import net.dv8tion.jda.core.JDABuilder;
import net.dv8tion.jda.core.OnlineStatus;
import net.dv8tion.jda.core.entities.Game;

import javax.security.auth.login.LoginException;

public class WhiteRanger {

    public static JDA jda;
    public static String prefix = "w!";
    public static String botChannelId;

    public static void main(String[] args) throws LoginException {
        jda = new JDABuilder(AccountType.BOT).setToken("NTUxNTM2NjkwMjI1NzQxODYx.D12SCg.JMpj7dTjyD2EvSGKAwkRuK-u0IA").buildAsync();

        jda.getPresence().setStatus(OnlineStatus.ONLINE);
        jda.getPresence().setGame(Game.playing("w!help"));

        jda.addEventListener(new BasicCommands());
        jda.addEventListener(new Clear());
        jda.addEventListener(new MemberJoin());


    }

}
